﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace IDClient
{
    class Program
    {
        private const string PIPE_NAME = "testNetworkPipe";

        static void Main(string[] args)
        {
            Console.WriteLine("请输入任何字符回车开始执行程序..");
            Console.Read();
            do
            {
                //内网服务器ip，必须是局域网
                string serverName = "127.0.0.1";
                //声明NamedPipeClientStream实例
                using (var clientStream = new System.IO.Pipes.NamedPipeClientStream(serverName, PIPE_NAME))
                {
                    //连接服务器
                    clientStream.Connect(1000);
                    //设置为消息读取模式
                    clientStream.ReadMode = System.IO.Pipes.PipeTransmissionMode.Message;

                    do
                    {
                        byte[] bytes = new byte[4];
                        clientStream.Read(bytes, 0, 4);
                        int val = BitConverter.ToInt32(bytes, 0);
                        Console.Write("NewID == " + val + "\r");
                    } while (!clientStream.IsMessageComplete);
                }

                Thread.Sleep(1);
            } while (true);
        }
    }
}
