﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


using System.IO;
using System.IO.Pipes;
using System.Threading;

namespace IDServer
{
    class Program
    {
        /// <summary>
        /// 命名管道名字
        /// </summary>
        private const string PIPE_NAME = "testNetworkPipe";

        //定义线程数，也是NamedPipeServerStream的允许最多的实例数
        private const int MAX_THREADS_COUNT = 3;
        private static volatile int _runingThreadCount = 0;

        private static volatile int _newId = 0;

        //实例数组
        private static NamedPipeServerStream[] _serverStreams;

        static void Main(string[] args)
        {
            _serverStreams = new NamedPipeServerStream[MAX_THREADS_COUNT];

            //在进程退出时释放所有NamedPipeServerStream实例
            AppDomain.CurrentDomain.ProcessExit += new EventHandler(CurrentDomain_ProcessExit);
            
            //启动线程
            StartServers();

            Console.Read();
        }

        /// <summary>
        /// 在进程退出时释放命名管道
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        static void CurrentDomain_ProcessExit(object sender, EventArgs e)
        {
            if (_serverStreams != null)
            {
                foreach (NamedPipeServerStream item in _serverStreams)
                {
                    item.Dispose();
                }
            }
        }

        /// <summary>
        /// 启动服务器端线程
        /// </summary>
        private static void StartServers()
        {
            for (int i = 0; i < MAX_THREADS_COUNT; i++)
            {
                Thread thread = new Thread(new ThreadStart(StartNewIDServer));
                thread.Start();
            }
        }


        /// <summary>
        /// 启动一个NamedPipeServerStream实例
        /// </summary>
        private static void StartNewIDServer()
        {
            NamedPipeServerStream stream = null;
            Console.WriteLine("start server in thread " + Thread.CurrentThread.ManagedThreadId);

            stream = _serverStreams[_runingThreadCount] = new NamedPipeServerStream(PIPE_NAME,
                 PipeDirection.InOut,
                 MAX_THREADS_COUNT,
                 PipeTransmissionMode.Message,
                 PipeOptions.None);
            int threadNo = _runingThreadCount;
            _runingThreadCount += 1;

            while (true)
            {
                stream.WaitForConnection();
                int newId = ++_newId;

                byte[] bytes = BitConverter.GetBytes(newId);
                stream.Write(bytes, 0, bytes.Length);
                stream.Flush();
                Console.Write("threadNo:" + Thread.CurrentThread.ManagedThreadId + "\r");
                stream.Disconnect();
            }
        }

    }
}
