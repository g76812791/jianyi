
/*div模拟select*/
$(".select_box").click(function(event){   
    event.stopPropagation();
    $(this).find(".option").toggle();
    $(this).parent().siblings().find(".option").hide();
});
$(document).click(function(event){
    var eo=$(event.target);
    if($(".select_box").is(":visible") && eo.attr("class")!="option" && !eo.parent(".option").length)
    $('.option').hide();           
});
$(".option li a").click(function(){
    var value=$(this).text();
    $(this).parent().parent().siblings(".select_txt").text(value);
    $("#select_value").val(value);
})


//hover
$(".hoverCont").hide();
$(".hover").bind("mouseover",function(){
    $(this).find(".hoverCont").show().css("z-index",1000);
    $(this).hover(function(){
        $(this).css("z-index", 999);
    },function(){
        $(this).find(".hoverCont").hide().css("z-index",1);
    });
});


// tree
$(function(){
    NTES("span.photo-search input[type=text]").addEvent("focus", function(){ this.value == this.defaultValue && (this.value = ""); }).addEvent("blur", function(){ this.value == "" && (this.value = this.defaultValue); });
    NTES("div.pnav-box div.box-title a.btn-fold").addEvent("click", function(e){
        e.preventDefault();
        var eleTitle = NTES(this.parentNode);
        NTES(this).addCss("hidden");
        eleTitle.$("a.btn-unfold").removeCss("hidden");
        NTES(eleTitle.parentNode).$("ul.box-list").removeCss("hidden");
    });
    NTES("div.pnav-box div.box-title a.btn-unfold").addEvent("click", function(e){
        e.preventDefault();
        var eleTitle = NTES(this.parentNode);
        NTES(this).addCss("hidden");
        eleTitle.$("a.btn-fold").removeCss("hidden");
        NTES(eleTitle.parentNode).$("ul.box-list").addCss("hidden");
    });
    NTES("div.pnav-box ul.box-list a.btn-fold").addEvent("click", function(e){
        e.preventDefault();
        var eleTitle = NTES(this.parentNode);
        NTES(this).addCss("hidden");
        eleTitle.$("a.btn-unfold").removeCss("hidden");
        eleTitle.$("h2").removeCss("hidden");
    });
    NTES("div.pnav-box ul.box-list a.btn-unfold").addEvent("click", function(e){
        e.preventDefault();
        var eleTitle = NTES(this.parentNode);
        NTES(this).addCss("hidden");
        eleTitle.$("a.btn-fold").removeCss("hidden");
        eleTitle.$("h2").addCss("hidden");
    });
    new NTES.ui.Slide(NTES("ul.photo-snav li"), NTES("div.photo-scnt"), "active", "mouseover", 6000);
})();