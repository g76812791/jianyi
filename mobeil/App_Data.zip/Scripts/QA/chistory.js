﻿
if (typeof (chis) == "undefined")
    _h = chis = {};

if (typeof (_h.History) == "undefined")
    _h.History = {};

_h.History = function (btnid, textid,callBack) {
    if (!document.getElementById)
        return 0;
    this.flds = _h.DOM.gE(textid);
    this.btid = _h.DOM.gE(btnid);
    if (!this.flds)
        return 0;
    this.tag = 0;
    this.sInp = "";
    this.aSug = [];
    this.iHigh = 0;
    this.idAs = "like_" + this.flds.id;
    var p = this;
    this.cb = callBack;

    this.flds.onclick = function (event) {
        if (p.flds.value.length == 0) {
        
            $("#as_searchWords").hide();
            p.tag = 0;
            if (p.tag == 1) {
                p.clearSuggestions("fades");
            }
            else {
                p.onsearchbtn();
                p.flds.onkeypress = function (ev) { return p.onKeyPress(ev); };
                p.flds.onkeydown = function (ev) { return p.onKeyUps(ev); };
                if ($("#head").css("position")=="fixed") {
                    var scrtop = $(document).scrollTop();
                    var csstop = $('#like_searchWords').css('top');
                    if (csstop != undefined) {
                        var reg = /\d+/;
                        var num = csstop.match(reg)[0];
                        $('#like_searchWords').css('top', (parseInt(scrtop) + parseInt(num)) + 'px');
                    }
                }

            }
        }
    }
};

var hiskey = "lawhis";
_h.History.prototype.DelStore = function (index) {
    var storage = window.localStorage;
    var qahislist = storage.getItem(hiskey);
    if (qahislist != null) {
        var arrhis = JSON.parse(qahislist);
        arrhis.splice(index, 1);
        storage.setItem(hiskey, JSON.stringify(arrhis));
    }
}
_h.History.prototype.Savelocalstorage = function (word) {
    if (word.length > 0) {
        var storage = window.localStorage;
        var qahislist = storage.getItem(hiskey);
        if (qahislist == null) {
            storage.setItem(hiskey, JSON.stringify([{ word: word }]));
        } else {
            var arrhis = JSON.parse(qahislist);
            for (var i = 0; i < arrhis.length; i++) {
                if (word === arrhis[i].word) {
                    arrhis.splice(i, 1);
                }
            }
            arrhis.push({ word: word });
            if (arrhis.length > 10) {
                arrhis.splice(0, 1);
            }
            storage.setItem(hiskey, JSON.stringify(arrhis));
        }
    }
}
_h.History.prototype.onsearchbtn = function () {
    var array = new Array();
    var storage = window.localStorage;
    var qahislist = storage.getItem(hiskey);
    if (qahislist != null) {
        var arrhis = JSON.parse(qahislist);
        var len = arrhis.length;
        for (var i = 0; i < len; i++) {
            var obj = arrhis.pop();
            if (obj.word != null) {
                array[i] = [];
                array[i][0] = len - i - 1;
                array[i][1] = obj.word;
            }
        }
    }
    this.createListtest(array);
};
_h.History.prototype.onKeyPress = function (ev) {
    var key = (window.event) ? window.event.keyCode : ev.keyCode;
    var RETURN = 13;
    var ESC = 27;
    var bubble = 1;
    switch (key) {
        case RETURN:
            this.setHighlightedValueToGo();
            bubble = 0;
            break;
        case ESC:
            this.clearSuggestions("fades");
            break;
    }
    return bubble;
};
_h.History.prototype.onKeyUps = function (ev) {
    var key = (window.event) ? window.event.keyCode : ev.keyCode;
    var ARRUP = 38;
    var ARRDN = 40;
    var ARRLEFT = 37;
    var ARRRIGHT = 39;
    var bubble = 1;
    switch (key) {
        case ARRUP:
            this.changeHighlight(key);
            bubble = 0;
            break;
        case ARRDN:
            this.changeHighlight(key);
            bubble = 0;
            break;
        case ARRLEFT:
            bubble = 0;
            break;
        case ARRRIGHT:
            bubble = 0;
            break;
        default:
            this.clearSuggestions("fades");
    }
    return bubble;
};
_h.History.prototype.createListtest = function (arr) {
    this.aSug = arr;
    var pointer = this;
    this.clearSuggestions();
    if (arr.length == 0)
        return false;
    this.tag = 1;
    var div = _h.DOM.cE("div", { id: this.idAs, className: "Autosug" });
    var hcorner = _h.DOM.cE("div", { className: "as_co  rner" });
    var hbar = _h.DOM.cE("div", { className: "as_bar" });
    /*var header = _h.DOM.cE("div", { className: "as_header" });
    header.appendChild(hcorner);
    header.appendChild(hbar);
    div.appendChild(header);*/
    var ul = _h.DOM.cE("ul", { id: "like_ul" });
    for (var i = 0; i < arr.length; i++) {
        var key = arr[i][0];
        var val = arr[i][1];     
        var output = val;
        var span = _h.DOM.cE("span", { className: "atxt90" }, HTMLEncode(output), true);
        var a = _h.DOM.cE("a", { href: "#", className: key });
        var tl = _h.DOM.cE("span", { className: "tl" }, " ");
        var tr = _h.DOM.cE("span", { className: "tr" }, " ");
        var close = _h.DOM.cE("span", { className: "chclose" }, " ");
        a.appendChild(tl);
        a.appendChild(tr);
        a.appendChild(close);
        a.appendChild(span);
        a.name = i + 1;
        a.onclick = function () { pointer.setHighlightedValueToGo(); return false; };
        a.onmouseover = function() {
            pointer.setHighlight(this.name);
        };
        var li = _h.DOM.cE("li", {}, a);
        close.onclick = function (e) {
            var index = $(e.target).parent().attr('class');
            pointer.DelStore(index);
            $(e.target).parent().parent().remove();
            stopBubble(e);
        }
        ul.appendChild(li);
    }
    if (arr.length == 0 && this.oP.shownoresults) {
        var liw = _h.DOM.cE("li", { className: "as_warning" }, this.oP.noresults);
        ul.appendChild(liw);
    }
    div.appendChild(ul);
    var fcorner = _h.DOM.cE("div", { className: "as_corner" });
    var fbar = _h.DOM.cE("div", { className: "as_bar" });
   /* var footer = _h.DOM.cE("div", { className: "as_footer" });
    footer.appendChild(fcorner);
    footer.appendChild(fbar);
    div.appendChild(footer);
   */
    var pos = _h.DOM.getPos(this.flds);
    div.style.left = pos.x+1 + "px";
    div.style.top = (pos.y + this.flds.offsetHeight + 6) + "px";
    div.style.width = this.flds.offsetWidth+4+ "px";
    window.onresize = function () {
        var pos = _h.DOM.getPos(pointer.flds);
        div.style.left = pos.x + "px";
    }
    document.body.onclick = function (event) {
        event=window.event|| event;
        var obj = event.srcElement ? event.srcElement : event.target;
        if (obj.id != pointer.flds.id) { pointer.resetTimeout(); }
    }
    document.getElementsByTagName("body")[0].appendChild(div);
    this.iHigh = 0;
};

_h.History.prototype.changeHighlight = function (key) {
    var list = _h.DOM.gE("like_ul");
    if (!list)
        return false;
    var n;
    if (key == 40)
        n = this.iHigh + 1;
    else if (key == 38)
        n = this.iHigh - 1;
    if (n >= list.childNodes.length + 1) {
        n = 1;
    }
    if (n <= 0) {
        n = list.childNodes.length;
    }
    this.setHighlight(n);
    this.setHighlightedValue();
};

_h.History.prototype.setHighlight = function (n) {
    var list = _h.DOM.gE("like_ul");
    if (!list)
        return false;
    if (this.iHigh > 0)
        this.clearHighlight();
    this.iHigh = Number(n);
    if (n > list.childNodes.length || n < 1) {
        this.killTimeout();
        return;
    }
    this.killTimeout();
};
_h.History.prototype.clearHighlight = function () {
    var list = _h.DOM.gE("like_ul");
    if (!list)
        return false;
    if (this.iHigh > 0) {
        this.iHigh = 0;
    }
};
_h.History.prototype.setHighlightedValueToGo = function () {
    if (this.iHigh) {

        this.setHighlightedValue();
        this.sInp = this.flds.value;
        this.clearSuggestions("fade");
        if (typeof (this.cb) == "function")
            this.cb();
    }
};
_h.History.prototype.setHighlightedValue = function () {
    if (this.iHigh) {

        var list = _h.DOM.gE("like_ul");
        var n = 0;

        if (this.iHigh == list.childNodes.length || this.iHigh == -1) {
            this.flds.value = this.aSug[this.iHigh - 1][1];
            n = this.flds.value.length;
        }
        else {

            this.flds.value = this.aSug[this.iHigh - 1][1];

            n = this.flds.value.length;
        }

        this.SetSelectRange(n);
    }
};
_h.History.prototype.SetSelectRange = function (nLength) {
    this.flds.focus();
    if (this.flds.selectionStart)
        this.flds.setSelectionRange(nLength, nLength);
};
_h.History.prototype.killTimeout = function () {
    clearTimeout(this.toID);
};
_h.History.prototype.resetTimeout = function () {
    clearTimeout(this.toID);
    var pointer = this;
    this.toID = setTimeout(function () { pointer.clearSuggestions("fade") }, 0);
};
_h.History.prototype.clearSuggestions = function (fade) {
    this.killTimeout();
  
    var ele = _h.DOM.gE(this.idAs);
    this.tag = 0;
    var pointer = this;
    if (ele)
        fade ? new _h.Fader(ele, 1, 0, 250, function () { _h.DOM.remE(pointer.idAs) }) : _h.DOM.remE(this.idAs);

};
if (typeof (_h.DOM) == "undefined")
    _h.DOM = {};
_h.DOM.cE = function (type, attr, cont, html) {
    var ne = document.createElement(type);
    if (!ne)
        return 0;
    for (var a in attr)
        ne[a] = attr[a];
    var t = typeof (cont);
    if (t == "string" && !html)
        ne.appendChild(document.createTextNode(cont));
    else if (t == "string" && html)
        ne.innerHTML = cont;
    else if (t == "object")
        ne.appendChild(cont);
    return ne;
};

_h.DOM.gE = function (e) {
    var t = typeof (e);
    if (t == "undefined")
        return 0;
    else if (t == "string") {
        var re = document.getElementById(e);
        if (!re)
            return 0;
        else if (typeof (re.appendChild) != "undefined")
            return re;
        else
            return 0;
    }
    else if (typeof (e.appendChild) != "undefined")
        return e;
    else
        return 0;
};
_h.DOM.remE = function (ele) {
    var e = this.gE(ele);
    if (!e)
        return 0;
    else if (e.parentNode.removeChild(e))
        return true;
    else
        return 0;
};

_h.DOM.getPos = function (e) {
    var e = this.gE(e);
    var obj = e;
    var curleft = 0;
    if (obj.offsetParent) {
        while (obj.offsetParent) {
            curleft += obj.offsetLeft;
            obj = obj.offsetParent;
        }
    }
    else if (obj.x)
        curleft += obj.x;
    var obj = e;
    var curtop = 0;
    if (obj.offsetParent) {
        while (obj.offsetParent) {
            curtop += obj.offsetTop;
            obj = obj.offsetParent;
        }
    }
    else if (obj.y)
        curtop += obj.y;
    return { x: curleft, y: curtop };
};

if (typeof (_h.Fader) == "undefined")
    _h.Fader = {};
_h.Fader = function (ele, from, to, fadetime, callback) {
    if (!ele)
        return 0;
    this.e = ele;
    this.from = from;
    this.to = to;
    this.cb = callback;
    this.nDur = fadetime;
    this.nInt = 50;
    this.nTime = 0;
    var p = this;
    this.nID = setInterval(function () { p._fade() }, this.nInt);
};

_h.Fader.prototype._fade = function () {
    this.nTime += this.nInt;
    var ieop = Math.round(this._tween(this.nTime, this.from, this.to, this.nDur) * 100);
    var op = ieop / 100;
    if (this.e.filters)
    {
        try {
            this.e.filters.item("DXImageTransform.Microsoft.Alpha").opacity = ieop;
        } catch (e) {
            this.e.style.filter = 'progid:DXImageTransform.Microsoft.Alpha(opacity=' + ieop + ')';
        }
    }
    else
    {
        this.e.style.opacity = op;
    }
    if (this.nTime == this.nDur) {
        clearInterval(this.nID);
        if (this.cb != undefined)
            this.cb();
    }
};
_h.Fader.prototype._tween = function (t, b, c, d) {
    return b + ((c - b) * (t / d));
};