﻿function MarkRed(str) {
    var reg1 = new RegExp("###", "g");
    var nstr = str.replace(/\$\$\$/g, "</font>");
    nstr = nstr.replace(reg1, "<font color=\"#FF0000\">");
    return nstr;
}
function qc(a) { // 去重
    var r = [];
    for (var i = 0; i < a.length; i++) {
        var flag = true;
        var temp = a[i];
        for (var j = 0; j < r.length; j++) {
            if (temp.QID === r[j].QID) {
                flag = false;
                break;
            }
        }
        if (flag) {
            r.push(temp);
        }
    }
    return r;
}
function quchong(a) { // 去重
    var r = [];
    for (var i = 0; i < a.length; i++) {
        var flag = true;
        var temp = a[i];
        for (var j = 0; j < r.length; j++) {
            if (temp.Content === r[j].Content || temp.Content === r[j].Content + '？') {
                flag = false;
                break;
            }
        }
        if (flag && temp.Content != $("#searchWords").val()) {
            r.push(temp);
        }
    }
    return r;
}

function replyCallback(reurl, qaApiAddress,kw) {
    return function () {
        $.ajax({
            url: qaApiAddress + 'GetQid?question=' + encodeURIComponent(kw),
            type: "get",
            dataType: "json",
            success: function (result) {
                if (result != null) {
                    window.location = reurl + '&qid=' + result;
                }
            }
        });
    }
}

///右侧推荐
function Recommend_question(recCount,NotIDClass, RecommendUrl,kw)
{
    //相关问题推荐  
    if (kw == "")
        return;
    var ids = GetNotIDValues(NotIDClass);    
    $.get(
     RecommendUrl + '/api/GetRecommended?source=KbaseFAQ&threshold=' + recCount + '&content=' + encodeURIComponent(kw), function (result) {
         if (result.length > 0) {
             
             var html = "";
             result = quchong(result);            
             
             $.each(result, function (i, e) {
                 if (ids.indexOf(e.QID) == -1)
                 {
                     html += $("#recq").html()
                      .replace(/{Content}/, e.Content.replace(/###/g, "").replace(/\$\$\$/g, ""))
                      .replace(/{Content}/, MarkRed(e.Content))
                      .replace(/{Title}/, e.Content).replace(/{QID}/, e.QID);
                 }
                 
             });
             if (html != "") {
                 $("#recquestion").append(html);
                 $('#recwt').show();
             }
             else {
                 $('#recwt').hide();
             }
         } 
     });

}

function GetNotIDValues(NotIDClass) {
    var ids = "";
    if ($("." + NotIDClass).length > 0) {

        $("." + NotIDClass).each(function () {
            ids += $(this).val() + ",";
        });
    }
    return ids;
}
//
function Recommend_Question_NoResult(recCount, NotIDClass, RecommendUrl, kw) {
    //相关问题推荐  
    if (kw == "")
        return;
    var ids = GetNotIDValues(NotIDClass);
    $.get(
     RecommendUrl + '/api/GetRecommended?source=KbaseFAQ&threshold=' + recCount + '&content=' + encodeURIComponent(kw), function (result) {
         if (result.length > 0) {

             var html = "";
             result = quchong(result);

             $.each(result, function (i, e) {
                 if (ids.indexOf(e.QID) == -1) {
                     html += $("#norecq").html()
                      .replace(/{Content}/, e.Content.replace(/###/g, "").replace(/\$\$\$/g, ""))
                      .replace(/{Content}/, MarkRed(e.Content))
                      .replace(/{Title}/, e.Content).replace(/{QID}/, e.QID);
                 }

             });
             if (html != "") {
                 $("#norecquestion").append(html);
                 $('#norecwt').show();
             }
             else {
                 $('#norecwt').hide();
             }
         }
     });

}

function HelpQuestion(recCount, RecommendUrl, QaApiAddress)
{
    //网友求助
    $.get(
        RecommendUrl + '/api/GetRecommended?source=fb_question&threshold=' + recCount + '&content=' + encodeURIComponent(kw), function (result) {
            if (result.length > 0) {
                $('#recqz').show();
                var html = "";
                result = qc(result);
                $.each(result, function (i, e) {
                    $.get(QaApiAddress + '/getanswer?QID=' + e.QID, function (time) {
                        html += $("#hidhot").html()
                            .replace(/{ID}/g, e.QID)
                            .replace(/{Content}/, encodeURIComponent(e.Content))
                            .replace(/{Content}/, HTMLEncode(e.Content))
                            .replace(/{Title}/, e.Content)
                            .replace(/{Time}/, time);
                        $("#ulhot").append(html);
                        html = "";
                    });
                });
            } else {
                //新求助
                $.ajax({
                    url: QaApiAddress + 'GetNewQuestion?size=10',
                    type: "get",
                    dataType: "json",
                    success: function (result) {
                        if (result.length > 0) {
                            $('#recx').show();
                        }
                        var html = "";
                        $.each(result, function (i, e) {
                            html += $("#hidhot").html()
                                .replace(/{ID}/g, e.ID)
                                .replace(/{Content}/, encodeURIComponent(e.Content))
                                .replace(/{Content}/, HTMLEncode(e.Content))
                                .replace(/{Title}/, e.Content)
                                .replace(/{Time}/g, e.CheckCount)
                        });
                        $("#ulx").empty().append(html); //装载对应分页的内容
                    }
                });
            }

        });
}

function getOffset(obj) {
    var arr = []
    var offsetL = 0
    var offsetT = 0
    while (obj != window.document.body && obj != null) {
        offsetL += obj.offsetLeft
        offsetT += obj.offsetTop
        obj = obj.offsetParent
    }
    arr.push(offsetL, offsetT)
    return arr
}
function More_tag_AddClick()
{
    $(".more_tag").click(function () {
        var $a = $(this).parent().parent();
        $a.css("background-color", "#E0EEE0");
        var items = $(this).parents(".item-section");
        var fbid = "";
        if (items.length > 0) {
            var fbdiv = $(items[0]).find(".fb_hid");
            if (fbdiv.length > 0) {
                fbid = $(fbdiv).attr("id");
            }
        }
        var msg = "<div class='item-section'>" + $(this).parent().parent().find('.msgmore').html() + "</div>";
        if (fbid != "")
        {
            msg += "<div style=\"text-align: center;\"><button type=\"button\" class=\"btn btn-default\" onclick=\"tjSGClick('" + fbid + "')\">不错，推荐作为参考答案</button></div>";
        }
        msg = "<div class='item-para' style='padding:30px 30px 100px 30px'>" + msg + "</div>";
        var offSetWidth = "820px";
        var areaWidth = "500px";
        var screenWidth = screen.width;
        if (screenWidth > document.body.clientWidth) {
            screenWidth = document.body.clientWidth;
        }
        var offSetThis = getOffset(this)[0];
        if (screenWidth < 768) {
            offSetWidth = "10px";
            areaWidth = screenWidth - 20 + "px";
        }
        else {
            var nAreaWidth = screenWidth - offSetThis - 120;
            if (nAreaWidth > 500) {
                nAreaWidth = 500;
            }
            offSetWidth = offSetThis + 120 + "px";
            areaWidth = nAreaWidth + "px";
        }
        layerindex = layer.open({
            type: 1,
            title: '',
            skin: 'layui-layer-demo',
            shade: 0.1,
            fixed: false,
            offset: ['80px', offSetWidth],
            closeBtn: 1,
            anim: 2,
            area: [areaWidth, ''],
            shadeClose: true,
            content: msg,
            end: function () {
                $a.css("background-color", "#ffffff");
            }
        });
    });
}

function tabs_nav_li_Init() {
    $(".tabs-nav-li").first().addClass("tabs-nav-selected");
    $(".tabs-content").hide();
    for (var i = 0; i < $(".item-para").size() ; i++) {
        $(".item-para").eq(i).find(".tabs-content:first").show();
    }
    $(".tabs-nav").each(function () {
        $(this).parent().find(".tabs-nav-li").first().addClass("tabs-nav-selected");
        $(this).parent().find(".tabs-content").hide();
        $(this).parent().find(".tabs-content").first().show();
    });
}
function tabs_nav_li_AddClick()
{
    $(".tabs-nav-li").click(function () {
        $(this).parent().find('.tabs-nav-li').removeClass("tabs-nav-selected");
        $(this).addClass("tabs-nav-selected");
        var tid = parseInt($(this).data("tid"));
        if (tid != undefined) {
            $(this).parent().parent().find('.tabs-content').hide();
            $(this).parent().parent().find('.tabs-content').each(function (index) {

                if (index == tid) {
                    $(this).show();
                    return;
                }
            });
        }
    });
}
function SetAnswerCount(c) {    
    var basec = parseInt($("#answercount").val());   
    basec = basec + c;
    $("#answercount").val(basec);
    if (basec > 0)
        $("#answercount_tip").html("为您找到 " + basec + "条结果");
}

function SetZeroTip(id) {
    var readyID = id + "_isready";
    var contentID = "content_" + id;
    if ($("#" + readyID).length > 0) {
        var c = parseInt($("#answercount").val());
        if (c == 0) {
            var zeroTip = '<div class="item clearfix"><div class="item-para"><div class="item-section">\
                    <span>抱歉，您输入的问题，我暂时还不能识别出它的意思。请访问 <a target="_blank" style="color:blue;" href="http://114.251.205.248:9090/#/homepage/homepage">人工回答</a></span>\
                        </div></div></div>';
            $("#" + contentID).append(zeroTip);
            $("#content_right").hide();

        }
    }
}
function itemHover() {
    $("#content_sg .item").hover(function () {
        
        $(this).find(".more_tag").text("显示更多");
    }, function () {
        $(this).find(".more_tag").text("");
    });
}