﻿ $(function () {
     $("#searchBtn,.list a").on('click', function () {
            $.ajax({
                type: "POST",
                url: "http://localhost:22479/api/KeyWord",
                data: { "": $("#searchWords").val() },
                success: function(data) {
                }
            });
        });
    });