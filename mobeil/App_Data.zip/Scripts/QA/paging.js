(function($, window, document, undefined) {
	//定义分页类
	function Paging(element, options) {
		this.element = element;
		//传入形参
		this.options = {
			pageNo: options.pageNo||1,
			totalPage: options.totalPage,
			totalSize:options.totalSize,
			callback:options.callback
		};
		//根据形参初始化分页html和css代码
		this.init();
	}
	//对Paging的实例对象添加公共的属性和方法
	Paging.prototype = {
		constructor: Paging,
		init: function() {
			this.creatHtml();
			this.bindEvent();
		},
		creatHtml: function () {
			var me = this;
			var content = "";

			var current = me.options.pageNo;
			var total = me.options.totalPage;
			var totalNum = me.options.totalSize;
            
		    if (current==1) {
		        content += '<a  id="firstPage" href="javascript:;" disabled="disabled" onclick="return false" class="pagenavon" >首页</a>'
		    } else {
		        content += '<a id="firstPage" href="javascript:;" onclick="return false" >首页</a>'
		    }
			content += '<a id="prePage" href="javascript:;" onclick="return false">上一页</a>'
			content += '<a id="nextPage" href="javascript:;" onclick="return false">下一页</a>'

			if (current!=1&&current == total) {
			    content += '<a id="lastPage" href="javascript:;" disabled="disabled" onclick="return false" class="pagenavon">尾页</a>'
			} else {
			    content += '<a id="lastPage" href="javascript:;" onclick="return false">尾页</a>'
			}
			me.element.html(content);
		},
		//添加页面操作事件
		bindEvent: function() {
			var me = this;
			me.element.off('click', 'a');
			me.element.on('click', 'a', function () {
			    if ($(this).attr("disabled") == "disabled") {
			        return;
			    }
				var num = $(this).html();
				var id=$(this).attr("id");
				if(id == "prePage") {
					if(me.options.pageNo == 1) {
					    me.options.pageNo = 1;
					    return;
					} else {
						me.options.pageNo = +me.options.pageNo - 1;
					}
				} else if(id == "nextPage") {
					if(me.options.pageNo == me.options.totalPage) {
					    me.options.pageNo = me.options.totalPage;
					    return;
					} else {
						me.options.pageNo = +me.options.pageNo + 1;
					}

				} else if(id =="firstPage") {
					me.options.pageNo = 1;
				} else if(id =="lastPage") {
					me.options.pageNo = me.options.totalPage;
				}else{
					me.options.pageNo = +num;
				}
				me.creatHtml();
				if(me.options.callback) {
					me.options.callback(me.options.pageNo);
				}
			});
		}
	};
	//通过jQuery对象初始化分页对象
	$.fn.paging = function(options) {
		return new Paging($(this), options);
	}
})(jQuery, window, document);