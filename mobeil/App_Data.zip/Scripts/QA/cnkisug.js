﻿var ISIE = navigator.userAgent.indexOf("MSIE") != -1 && !window.opera;
//初始自动补全绑定
function InitSug(sugserver) {
    createdroplist();
    var exp = "#searchWords";
    BindDroplist(exp, sugserver);
}

//绑定输入提示
function BindDroplist(exp, sugserver) {
//    if (!sugserver)
//        return;
    var objouter = $("#__droplist"),
        dictType = "",
        objinput = null,
        preinput = "",
        preDictType = "";
    inputid = "",
        listIputID = "",
        selindex = -1;
    //$(exp).bind("blur", function () { objouter.css("display", "none"); });
    $(exp).bind("keyup", function (evt) {
        inputid = $(this).attr('id');
        objinput = $("#" + inputid);
        var key = objinput.val();
        key = key.replace(/(^\s*)|(\s*$)/g, "");
        if (key == "") { objouter.hide(); return; }
        FillKeyType();
        var keycode = (evt.keyCode) || (evt.which) || (evt.charCode);
        if (!(keycode == 40 || keycode == 38 || keycode == 13)) {
            if (key == preinput && preDictType == dictType) {
                PreReturn(key);
                return;
            }
        }
        if ((keycode == 37 || keycode == 39) && inputid == listIputID && preDictType == dictType) {
            PreReturn(key);
            return;
        }
        if (keycode == 40 || keycode == 38) { //上下
            var isUp = false;
            if (keycode == 40)
                isUp = true;
            changeSelList(isUp);
        }
        else if (keycode == 13) { //回车           
            if (typeof firstTag != "undefined" && firstTag == true) {
                objouter.hide();
                firstTag = false;
            }
            else if (selindex != -1) {
                selectText();
                objouter.hide();
                selindex = -1;
            }
            else if (key != preinput || inputid != listIputID || preDictType != dictType)
                searchKeyWord();
            else objouter.hide();
        }
        else {
            searchKeyWord();
        }
        preDictType = dictType;
        preinput = key;

    });

    //提前返回处理
    function PreReturn(key) {
        divPosition();
        objouter.show();
        preDictType = dictType;
        preinput = key;
    }

    //添加监听事件
    function O(G, U, C) {
        if (ISIE) {
            if (U == "load") {
                G.onreadystatechange = function () {
                    if (this.readyState == "loaded") {
                        C();
                    }
                }
            }
            else
                G.attachEvent("on" + U, (function (V) { return function () { C.call(V) } })(G))

        }
        else {
            G.addEventListener(U, C, false)
        }
    }
    //做跨域脚本支持
    function CoreDomainLoadJson() {
        this.C;
        this.J = J;
        this.O = O;
        this.Load = function (src, onJsonLoaded, id) {
            if (this.C) {
                document.body.removeChild(this.C);
            }
            this.C = J("SCRIPT");
            if (typeof id == "string" && id.length > 0) {
                this.C.id = id;
            }
            else {
                this.C.id = "callScriptE";
            }
            this.C.src = src + "&td=" + (new Date()).getTime();
            this.C.charset = "utf-8";
            document.body.appendChild(this.C);
            O(this.C, "load", onJsonLoaded);
        }
    }

    //填充检索项词典类型
    function FillKeyType() {
        var selID = inputid.replace('value1', 'sel1').replace('value2', 'sel2');
        if ($("#" + selID).length <= 0)
            selID = inputid.replace('value1', 'sel').replace('value2', 'sel');
        var selValue = $("#" + selID).val();
        if (selValue == undefined)
            dictType = GetSpecKeyType();
        else
            dictType = selValue;
    }

    //获取特殊字段绑定词典类型
    function GetSpecKeyType() {
        if (inputid.indexOf('magazine_') == 0) {
            return "source";
        }
        if (inputid.indexOf('base') == 0) {
            return "base";
        }
        return "";
    }
    //提交检索，返回提示词内容列表
    function searchKeyWord() {
        listIputID = inputid;
        var kw = $("#" + inputid).val().replace(/(^\s*)|(\s*$)/g, "");
        if (kw != "") {
            divPosition();
            selindex = -1;
            objouter.empty();
            var geturl = sugserver + "/sug/su.ashx?action=getsmarttips&kw=" + encodeURI(kw) + "&t=" + encodeURI(dictType) + "&p=" + Math.random();
            var CoreDomainClass = new CoreDomainLoadJson();
            CoreDomainClass.Load(geturl, function () {
                if (typeof oJson != "undefined") {
                    if (oJson.Count == "0") {
                        objouter.hide();
                    }
                    else {
                        var html = oJson.sug;
                        objouter.empty();
                        if (html != null && html != "" && $("#" + inputid).val().replace(/(^\s*)|(\s*$)/g, "") != "") {
                            createlist(html);
                            objouter.show();
                        }
                        else {
                            objouter.hide();
                        }
                    }
                }

            },"sugkeyword_JS");
        }
        else {
            objouter.hide();
        }
    }

    function bold(data, input) {
        var ret = data;
        if (input && data.indexOf(input) == 0) {
            ret = input + "<strong>" + data.substr(input.length) + "</strong>"
        }
        return ret
    }

    //创建提示下拉框
    function createlist(result) {
        var rows = result.toLowerCase().split(";");
        var formathtml;
        var key = objinput.val().replace(/(^\s*)|(\s*$)/g, "");
        key = key.toLowerCase();
        for (var ix = 0; ix < rows.length; ix++) {
            if (rows[ix] == null || rows[ix] == "")
                continue;
            var cols = rows[ix].split(",");
            //cols[0] = cols[0].replace(eval("/^" + key + "/ig"), "<strong>" + key + "</strong>");
            cols[0] = bold(cols[0], key);
            formathtml = "<div onmouseover=\"this.className='drop_selected'\" onmouseout=\"this.className=''\" onmousedown=\"$('#'+'" + inputid + "').val('" + valueFilter(cols[0]) + "');try {ge('btnSearch').click();;} catch (e) {};\">" +
            "<span class='rw' id='rw" + ix + "'>" + cols[0] + "</span>" +
           
            "</div>";
            objouter.append(formathtml);
        }
    }

    //更改提示选择
    function changeSelList(isUp) {
        if (objouter.children().length == 0) {
            return;
        }
        if (objouter.css("display") == 'none') {
            objouter.css("display", "");
        }
        else {
            if (isUp)
                selindex++;
            else
                selindex--;
        }
        var maxindex = objouter.children().length - 1;

        if (selindex < 0) { selindex = 0; }
        if (selindex > maxindex) { selindex = maxindex; }

        var $childs = objouter.children();
        $childs.removeClass("drop_selected");
        $($childs[selindex]).addClass("drop_selected");
        var item = $(objouter.children()[selindex]).find("#rw" + selindex);
        objinput.val(valueFilter(item.text()));

    }

    //过滤检索提示词
    function valueFilter(sValue) {
        sValue = sValue.replace("<strong>", "").replace("</strong>", "");
        if (sValue.indexOf("/") >= 0)
            sValue = sValue.substring(0, sValue.indexOf("/"));
        return sValue;
    }

    function selectText() {
        if (selindex == -1)
            return;
        var item = $(objouter.children()[selindex]).find("#rw" + selindex);
        objinput.val(valueFilter(item.text()));

    }
    function divPosition(evt) {
        var offset = objinput.offset();
        var width = objinput.outerWidth();
        var height = objinput.outerHeight();
        objouter.css("top", offset.top + height);
        objouter.css("left", offset.left);
        objouter.css("width", width - 2);
    }
}

function J(C) {
    return document.createElement(C)
}
function createdroplist() {
    var droplist = document.getElementById("__droplist");
    if (droplist) {
        document.body.removeChild(droplist)
    }
    droplist = J("div");
    droplist.id = "__droplist";
    droplist.name = "__droplist";
    if (droplist.className != "undefined")
        droplist.className = "dictdiv";
    droplist.setAttribute("class", "dictdiv");
    document.body.appendChild(droplist);
}