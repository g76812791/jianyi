﻿function queryBase(url, htmlID, loadingID) {
     
    var token =$("input[name='__RequestVerificationToken']").val();
    var headers = {};
    headers["__RequestVerificationToken"] = token;
    $.ajax({
        url: url,
        headers: headers,
        type: "Get",
        beforeSend: function () {            
            $("#" + loadingID).show();
        },
        complete: function () {
                $("#" + loadingID).hide();
        },
        success: function (data) {
            $("#" + loadingID).hide();
            if (data != "") {
                $("#" + htmlID).show();
                $("#" + htmlID).html(data);
            }
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            if (textStatus != "error") {
                showMessage(textStatus, "hd");
            }
            $("#" + loadingID).hide();
        }
    });
}

function Search(qurl,clsID,tbID,callBack) {
    this.QueryURL = qurl;
    this.TBID = tbID;
    this.CLSID = clsID;
    this.cb = callBack;
}


Search.prototype.Submit = function()
{
    if ($.trim($("#" + this.TBID).val()).length == 0) {
        showMessage("请输入检索词");
        return;
    }
    var inputWords = $("#" + this.TBID).length > 0 ? $("#" + this.TBID).val() : "";

    var cls = $("#" + this.CLSID).length > 0 ? $("#" + this.CLSID).val() : "";
     
    this.s(inputWords, cls);
}
Search.prototype.SubmitTxt = function (q) {
    var inputWords = q.substring(0, 126);
    var cls = $("#" + this.CLSID).val();
    this.s(inputWords, cls);
}
Search.prototype.s = function (input,cls) {
    var url = this.QueryURL;
    url += "?q=" + encodeURIComponent(input) + "&cls="+cls+"&r=query" + "&t=" + Math.random();
    window.location.href = url;
    if (typeof (this.cb) == "function")
        this.cb();
}

function getUrlParam(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)"); //构造一个含有目标参数的正则表达式对象
    var r = window.location.search.substr(1).match(reg);  //匹配目标参数
    if (r != null) return decodeURIComponent(r[2]); return ''; //返回参数值
}
function showMessage(message, type) {
    var html = '<div class="popwrap"><div class="poptip"><a href="#" class="close" onclick="closeTip(this)">';
    html += ' <span class="disn">x</span></a>' + message + '</div></div>';
    $(".tip").html(html);
    setTimeout(function () {
        $(".popwrap").remove();
    }, 4000);
}

function HTMLEncode(html) {
    var temp = document.createElement("div");
    (temp.textContent != null) ? (temp.textContent = html) : (temp.innerText = html);
    var output = temp.innerHTML;
    temp = null;
    return output;
}

function HTMLDecode(text) {
    var temp = document.createElement("div");
    temp.innerHTML = text;
    var output = temp.innerText || temp.textContent;
    temp = null;
    return output;
}
function stopDefault(e) {
    //如果提供了事件对象，则这是一个非IE浏览器   
    if (e && e.preventDefault) {
        //阻止默认浏览器动作(W3C)  
        e.preventDefault();
    } else {
        //IE中阻止函数器默认动作的方式   
        window.event.returnValue = false;
    }
    return false;
}
function stopBubble(e) {
    //如果提供了事件对象，则这是一个非IE浏览器  
    if (e && e.stopPropagation) {
        //因此它支持W3C的stopPropagation()方法  
        e.stopPropagation();
    } else {
        //否则，我们需要使用IE的方式来取消事件冒泡   
        window.event.cancelBubble = true;
    }
    return false;
}
