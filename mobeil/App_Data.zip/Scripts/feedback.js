﻿if (typeof (cfdb) == "undefined")
    _fback = cfdb = {};

if (typeof (_fback.createDiv) == "undefined")
    _fback.createDiv = {};
if (typeof (_fback.url) == "undefined")
    _fback.url = "";

_fback.seturl = function (fburl) {
    _fback.url = fburl;
    urladdress = fburl;
};
_fback.createDiv = function (doms) {
    $.each(doms, function (i, value) {
        var $container = $(doms[i]); //循环遍历每一个dom节点
        id = $(doms[i]).attr("name");

    });
};

_fback.ids = [];
_fback.create = creatr;

_fback.createlist = createList;
function createList() {
    var username = $('#username').html();
    if (username == "" || username == null) {
        username = NameSpace.keyword.UserId.GetCookie("qa_cnki_net_uid");
    }
    var url = urladdress + 'GetEvaluate';
    var contentType = "application/json; charset=utf-8";
    if (window.XDomainRequest)
        contentType = "text/plain";

    $.ajax({
        url: url,
        type: "post",
        data: JSON.stringify(_fback.ids),
        dataType: "json",
        contentType: contentType,
        success: function (data) {
            var arr = data.data;
            for (var i = 0; i < arr.length; i++) {
                var dom = document.getElementById(arr[i].ahash);
                $(dom).find("span>b").eq(0).text(arr[i].good);
                $(dom).find("span>b").eq(1).text(arr[i].bad);
                //$(dom).find("span").addClass("evaluated");
            }
        }
    });
}

function creatr(dom, id) {
    $('<div style="height:13px;"></div><div style="float:right;margin-top: -13px;" id="' + id + '"><span title="给力"   class="evaluate" onclick="fb_evaclick(this,true,0)" data-evaluate="0"><b class="evaluate-num evaluate-num-fixed" id="118-num" >0</b></span> <span title="不给力"  onclick="fb_evaclick(this,0,true)"  class="evaluate evaluate-bad"  data-evaluate="0"><b class="evaluate-num evaluate-num-fixed" id="68-bad-num" style="display: inline-block;width:auto;">0</b></span></div>').insertAfter($(dom));
    // fb_eval(id);
    _fback.ids.push(id);
};
function fb_eval(id) {
    var dom = document.getElementById(id);
    if (dom == null)
        return;
    var username = $('#username').html();
    if (username == "" || username == null) {
        username = NameSpace.keyword.UserId.GetCookie("qa_cnki_net_uid");
    }
    var qstr = $("#searchWords").val();
    var url = urladdress + 'GetEvaluate' + '?qstr=' + encodeURIComponent(qstr) + '&ahash=' + id + '&uname=' + username;
    var contentType = "application/x-www-form-urlencoded; charset=utf-8";
    if (window.XDomainRequest)
        contentType = "text/plain";

    $.ajax({
        url: url,
        type: "get",
        dataType: "json",
        contentType: contentType,
        success: function (data) {
            $(dom).find("span>b").eq(0).text(data.data.good);
            $(dom).find("span>b").eq(1).text(data.data.bad);
            if (data.data.isgood || data.data.bad) {
                $(dom).find("span").addClass("evaluated");
            }
        }
    });
};
function fb_evaclick(dom, good, bad) {

    var id = $(dom).parent().attr('id');
    var fdom = document.getElementById(id);
    if ($(dom).hasClass('evaluated')) {
        layer.msg("您已经做过评价");
        return;
    };
    var username = $('#username').html();
    if (username == "" || username == null) {
        username = NameSpace.keyword.UserId.GetCookie("qa_cnki_net_uid");
    }
    var url = "";
    if (good) { url = urladdress + "SetGood"; }
    if (bad) { url = urladdress + "SetBad"; }
    var contentType = "application/x-www-form-urlencoded; charset=utf-8";
    if (window.XDomainRequest)
        contentType = "text/plain";

    var dataparm = {
        q: $("#searchWords").val(),
        answerID: id,
        uid: username
    }
    $.ajax({
        url: url + '?' + $.param(dataparm),
        contentType: contentType,

        type: 'post',
        dataType: 'json',
        success: function (data) {
            if (data.success == true) {
                fb_eval(id);
            } else {
                layer.msg("您已经做过评价");
            }
        },
        error: function () {
            layer.msg("异常！");
        }
    });
}
function fb_eva(id) {

    var dom = document.getElementById(id);
    if (dom == null)
        return;
    var username = $('#username').html();
    if (username == "" || username == null) {
        username = NameSpace.keyword.UserId.GetCookie("qa_cnki_net_uid");
    }
    var url = urladdress + 'evaluate' + '?qstr=' + $("#searchWords").val() + '&ahash=' + id + '&uname=' + username;
    $.get(url, function (data) {
        var cid = id + "_count";
        if (data.good == 0) {
            $('#' + cid).html("");
        }
        else {
            $('#' + cid).html(data.good);
        }

        if (data.isgood) {
            $(dom).addClass("is-active");
        }

    });
}
function tjSGClick(fbid) {
    var username = $('#username').html();
    if (username == "" || username == null) {
        username = NameSpace.keyword.UserId.GetCookie("qa_cnki_net_uid");
    }
    var url = urladdress + "SetSenGroup";
    var items = $("#" + fbid).parents(".item-section");
    var context = "";
    var subcontext = "";
    var regS = new RegExp("<font color=\"#FF0000\">", "g");
    var regE = new RegExp("</font>", "g");
    var $ps = $(items).children("p");
    $ps.each(function () {
        context += $(this).html();
    });
    subcontext = $(items).find(".msgmore").html();
    if (typeof (subcontext) != "undefined") {
        subcontext = subcontext.replace(regS, "###");
        subcontext = subcontext.replace(regE, "$$$");
        subcontext = $("<p>" + subcontext + "</p>").text();
    }
    if (typeof (context) != "undefined") {
        context = context.replace(regS, "###");
        context = context.replace(regE, "$$$");
        context = $("<p>" + context + "</p>").text();
    }
    
    var dataparm = {
        question: $("#searchWords").val(),
        hid: fbid,
        uid: username,
        title: $(items).find(".fb_title").val(),
        source_db: $(items).find(".fb_sdb").val(),
        source_id: $(items).find(".fb_sid").val(),
        context: context,
        subcontext: subcontext,
        uip:$("#uip").val()
    }

    //var contentType = "application/json; charset=utf-8";
    //if (window.XDomainRequest)
    //    contentType = "text/plain";
    $.ajax({
        url: url,
        data: dataparm,
        //data: JSON.stringify(dataparm),
        type: 'post',
        dataType: 'json',
        //contentType: contentType,
        success: function (data) {
            if (data.success == true) {
                layer.msg("推荐成功，感谢您的参与", { icon: 1, time: 2000 });
                layer.close(layerindex);
            } else {
                layer.msg('您已经做过评价', { time: 2000 });
            }
        },
        error: function () {
            layer.msg("异常！", { time: 2000 });
        }
    });
}
function usereval(qid, aid, isgood, status) {
    var ctype = "application/json";
    if (window.XDomainRequest)
        ctype = "text/plain";
    if (status == '0') {
        layer.msg("该答案尚未审核！", { time: 1000 });
        return;
    }
    var username = getCookie("qacnkiuser");

    if (username == "" || username == null)
        username = NameSpace.keyword.UserId.GetCookie("qa_cnki_net_uid");
    var query = {};
    if (isgood) {
        query = { qid: qid, answerid: aid, userid: username, good: 1 };
    } else {
        query = { qid: qid, answerid: aid, userid: username, bad: 1 };
    }
    var url = urladdress + 'UserEvaluate';
    $.ajax({
        contentType: ctype,
        type: 'post',
        url: url,
        data: JSON.stringify(query),
        dataType: "json",
        beforeSend: function () { $("#msg").html("logining"); },
        success: function (data) {
            if (data.IsSuccess) {
                if (isgood) {
                    draweval(aid, 1, 0);
                } else {
                    draweval(aid, 0, 1);
                }
            } else {
                layer.msg(data.Message);
            }

        },
        complete: function (XMLHttpRequest, textStatus) {

        },
        error: function () {
        }
    });

};
function draweval(id, good, bad) {
    var dom = document.getElementById(id);
    $(dom).find("span").addClass("evaluated");
    var txtgood = parseInt($(dom).find("span>b").eq(0).text()) + parseInt(good);
    var txtbad = parseInt($(dom).find("span>b").eq(1).text()) + parseInt(bad);
    $(dom).find("span>b").eq(0).text(txtgood);
    $(dom).find("span>b").eq(1).text(txtbad);
};






function qReport(qid, type) {
    layer.confirm('确定举报吗？', {
        btn: ['确定', '取消']
    }, function () {
        var ctype = "application/json";
        if (window.XDomainRequest)
            ctype = "text/plain";
        var username = getCookie("qacnkiuser");

        if (username == "" || username == null)
            username = NameSpace.keyword.UserId.GetCookie("qa_cnki_net_uid");
        var query = {};

        query = { qid: qid, uid: username, type: type };

        var url = urladdress + 'QPass';
        $.ajax({
            contentType: ctype,
            type: 'post',
            url: url,
            data: JSON.stringify(query),
            dataType: "json",
            beforeSend: function () { $("#msg").html("logining"); },
            success: function (data) {
                if (data.IsSuccess) {
                    layer.msg('已发送');
                } else {
                    layer.msg(data.Message);
                }

            },
            complete: function (XMLHttpRequest, textStatus) {

            },
            error: function () {
            }
        });
    }, function (index) {
        layer.close(index);
    });

}
function aReport(aid, type) {


    layer.confirm('确定举报吗？', {
        btn: ['确定', '取消']
    }, function () {
        var ctype = "application/json";
        if (window.XDomainRequest)
            ctype = "text/plain";
        var username = getCookie("qacnkiuser");

        if (username == "" || username == null)
            username = NameSpace.keyword.UserId.GetCookie("qa_cnki_net_uid");
        var query = {};

        query = { aid: aid, uid: username, type: type };

        var url = urladdress + 'APass';
        $.ajax({
            contentType: ctype,
            type: 'post',
            url: url,
            data: JSON.stringify(query),
            dataType: "json",
            beforeSend: function () { $("#msg").html("logining"); },
            success: function (data) {
                if (data.IsSuccess) {
                    layer.msg('已发送');
                } else {
                    layer.msg(data.Message);
                }
            },
            complete: function (XMLHttpRequest, textStatus) {

            },
            error: function () {
            }
        });
    }, function (index) {
        layer.close(index);
    });

}
function qHover() {
    $("#qr").hover(function () {
        $(this).find(".ablue").show();
    }, function () {
        $(this).find(".ablue").hide();
    });
}

function aHover() {
    $("#huida tr").on("mouseover mouseout", function (event) {
        if (event.type == "mouseover") {
            $(this).find(".ablue").show();
        } else if (event.type == "mouseout") {
            $(this).find(".ablue").hide();
        }
    })

}