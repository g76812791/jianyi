﻿/// <reference path="md5.js" />
/// <reference path="md5.js" />
window.onscroll = function () {
    var t = document.documentElement.scrollTop || document.body.scrollTop;
    if (t >= 300) {
        //alert('1');
    } else {
        //alert('2');
        $('.collapse').collapse('hide');
        //top_div.style.display = "none";
    }
}
var isaddvoice = false;
var browser = {
    versions: function () {
        var u = navigator.userAgent, app = navigator.appVersion;
        return {//移动终端浏览器版本信息  
            trident: u.indexOf('Trident') > -1,//IE内核  
            presto: u.indexOf('Presto') > -1,//opera内核  
            webKit: u.indexOf('AppleWebKit') > -1,//苹果、谷歌内核  
            gecko: u.indexOf('Gecko') > -1 && u.indexOf('KHTML') == -1, //火狐内核  
            mobile: !!u.match(/AppleWebKit.*Mobile.*/) || !!u.match(/AppleWebKit/),//是否为移动终端  
            ios: !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/),//ios终端  
            android: u.indexOf('Android') > -1 || u.indexOf('Linux') > -1, //android终端或者uc浏览器  
            iPhone: u.indexOf('iPhone') > -1 || u.indexOf('Mac') > -1, //是否为iPhone或者QQHD浏览器  
            iPad: u.indexOf('iPad') > -1,//是否iPad  
            webApp: u.indexOf('Safari') == -1//是否web应该程序，没有头部与底部  
        };
    }(),
    language: (navigator.browserLanguage || navigator.language).toLowerCase()
}
if (browser.versions.android){
    if (browser.versions.gecko || browser.versions.webKit) {
        isaddvoice = true;
        //alert("是否加载：" + isaddvoice);
    }
    //隐藏语音功能
    isaddvoice = false;
}
//addscript();
if (isaddvoice) {
    addscript();
    //alert("加载JS");
};
var h5searchid = "";
function addhticon(id, pid, clickname, picurl, pclass) {
    var str = '  role="button" data-toggle="collapse" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne"   style="width:32px"';
    //$("#" + id).after("<img style='display:none'  id=" + pid + " src=" + picurl + " class=" + pclass + " onclick=" + + "()" + str + ">");
    $("#" + id).after('<div id="preloader_1" style="display:none"><span></span><span></span><span></span><span></span><span></span></div>');
    h5searchid = id;
    //if (!isaddvoice) {
    //    $("#searchWords").removeAttr("onfocus");
    //}
    //<a id="apiurl" style="display:none" href="~/api/Getstr" class="s_close"></a>
};
function LoadJS(fileUrl) {
    var oHead = document.getElementsByTagName('HEAD').item(0);
    var oScript = document.createElement("script");
    oScript.type = "text/javascript";
    oScript.src = fileUrl;
    oHead.appendChild(oScript);
}
function addscript() {
   // LoadJS("http://blog.faultylabs.com/files/md5.js");//~/Scripts/md5.js
    //LoadJS("~/Scripts/md5.js");
    LoadJS("http://webapi.openspeech.cn/socket.io/socket.io.js");
    LoadJS("http://webapi.openspeech.cn/js/util/zepto.min.js");
    LoadJS("http://webapi.openspeech.cn/js/util/jwav.min.js");
    LoadJS("http://webapi.openspeech.cn/fingerprint.js");
    LoadJS("http://webapi.openspeech.cn/iat.min.js");
    //<script src="http://webapi.openspeech.cn/h5api/js/jquery-2.1.1.min.js"></script>	
    // <script src="http://webapi.openspeech.cn/h5api/js/jquery.md5.js"></script>		
    // <script src="http://webapi.openspeech.cn/socket.io/socket.io.js"></script>
    // <script src='http://webapi.openspeech.cn/js/util/zepto.min.js'></script>
    // <script src='http://webapi.openspeech.cn/js/util/jwav.min.js'></script>
    // <script src='http://webapi.openspeech.cn/fingerprint.js'></script>
    // <script src="http://webapi.openspeech.cn/iat.min.js"></script>
};
var session = null;
function h5voiceinti(speex_path, vad_path, recorder_path) {
    session = new IFlyIatSession({
        'url': 'http://webapi.openspeech.cn/',
        'reconnection': true,
        'reconnectionDelay': 30000,
        'compress': 'speex',
        'speex_path': speex_path,              //speex.js本地路径
        'vad_path': vad_path,                  //vad.js本地路径
        'recorder_path': recorder_path    //recordWorker.js本地路径
    });
    return session;
};

function testvoice() {
    alert("testvoice");
}
/**
  * 开启录音并获取识别结果
  */
function H5Voicestart(id) {
    //alert("开始");
    console.log("开始");
    var apiurl = document.getElementById("apiurl");
    //$("#" + id).addClass('animated shake');
    //setTimeout(function () {
    //    $("#" + id).removeClass('shake');
    //}, 1000);
    var appid = '56c6772c';                              //应用APPID，在open.voicecloud.cn上申请即可获得
    var timestamp = new Date().toLocaleTimeString();                      //当前时间戳，例new Date().toLocaleTimeString()
    var expires = 60000;                          //签名失效时间，单位:ms，例60000
    //!!!为避免secretkey泄露，签名函数调用代码建议在服务器上完成
    //var secret_key = '72bc2d4e012eef8e';
    //alert(timestamp);
    var signature;
    // signature = faultylabs.MD5(appid + '&' + timestamp + '&' + expires + '&' + secret_key);
    //alert(apiurl);
    $("#" + h5searchid).attr("placeholder", "");
    var isshow = false;
    
    $.ajax({
        type: "post",
        url: apiurl + "?timestamp=" + timestamp,
        dataType: "json",
        success: function (msg) {
            console.log(msg);
           // $('#preloader_1').show();
            signature = msg;
            var params = { "grammar_list": null, "params": "aue=speex-wb;-1, usr = mkchen, ssm = 1, sub = iat, net_type = wifi, ent =sms16k, rst = plain, auf  = audio/L16;rate=16000, vad_enable = 1, vad_timeout = 5000, vad_speech_tail = 500, caller.appid = " + appid + ",timestamp = " + timestamp + ",expires = " + expires, "signature": signature };
            //alert("2");
            /* 调用开始录音接口，通过function(volume)和function(err, obj)回调音量和识别结果 */
            session.start(params, function (volume) {
                console.log(3);
                //alert("3");
                //alert(volume);
                if (volume < 0)
                {
                    $('#preloader_1').hide();
                    alert("麦克风启动失败");
                    console.log('closedonghua');
                }
                    
                /* 获取并展示当前录音音量 */
                if (volume < 6 && volume > 0) {
                    if (!isshow) {
                        console.log('opendonghua');
                        $("#searchWords").val("");
                        $('#preloader_1').show();
                        isshow = true;
                    }
                   
                    console.log("volume : " + volume);
                    $("#" + id).addClass('animated pulse');
                    setTimeout(function () {
                        $("#" + id).removeClass('pulse');
                    }, 1000);
                }
                //

                /* 若volume返回负值，说明麦克风启动失败*/

            }, function (err, result) {
                console.log('err:' + err);
                console.log('result:' + result);
                /* 若回调的err为空或错误码为0，则会话成功，可提取识别结果进行显示*/
                if (err == null || err == undefined || err == 0) {
                    if (result == '' || result == null)
                        $("#searchWords").val("没有获取到识别结果");
                        //document.getElementById('result').innerHTML = "没有获取到识别结果";
                    else {
                        //alert(result);
                        $("#searchWords").val(result);
                        //searchandstore(result);
                        var btn = document.getElementById("searchBtn");
                        btn.click();
                        //document.getElementById('result').innerHTML = result;
                    }
                    /* 若回调的err不为空且错误码不为0，则会话失败，可提取错误码 */
                } else {
                    //document.getElementById('result').innerHTML = 'error code : ' + err + ", error description : " + result;
                    $("#searchWords").val('error code : ' + err + ", error description : " + result)
                }
            }, function (message) {
                if (message == 'onStop') {
                    console.log("close&Stop");
                    $('#preloader_1').hide();
                    $("#" + h5searchid).attr("placeholder", "语音结束请等待结果，长时间没有结果请再说一次");
                } else if (message == 'onEnd') {
                    console.log("会话结束");
                    $('#preloader_1').hide();
                    console.log("close结束");
                    $("#" + h5searchid).attr("placeholder", "说出你的问题");
                }
            }, function (data) {
                console.log(data);
            });
            /* 读取音频文件 */
            file.onload = function (onEvent) {
                var arrayBuffer = file.response;
                if (arrayBuffer) {
                    byteArray = new Int16Array(arrayBuffer);
                    console.log(byteArray.length);
                    window.setTimeout(writeAudioData, 20);
                }
            }
        }
    });
  
    //alert("1");
    //var signature = faultylabs.MD5(appid + '&' + timestamp + '&' + expires + '&' + secret_key);
   

};
function writeAudioData() {
    if (byteArray.length > 320) {
        window.setTimeout(writeAudioData, 20);
        var data = byteArray.subarray(0, 320);
        byteArray = byteArray.subarray(320, byteArray.length);
        session.writeAudio(data, 2);
    } else {
        session.writeAudio(byteArray, 4);
    }
}
function stop() {
    session.stop(null);
};