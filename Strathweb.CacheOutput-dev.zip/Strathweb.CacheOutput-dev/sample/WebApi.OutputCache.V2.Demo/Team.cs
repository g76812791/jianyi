﻿namespace WebApi.OutputCache.V2.Demo
{
    public class Team
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string League { get; set; }
    }
}